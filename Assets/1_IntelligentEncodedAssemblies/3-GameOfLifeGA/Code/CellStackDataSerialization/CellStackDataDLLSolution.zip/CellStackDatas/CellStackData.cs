﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace RC3
{
    namespace GameOfLifeGA
    {
        [System.Serializable]
        /// <summary>
        /// 
        /// </summary>
        public struct CellStackData
        {
            private int _columnCount;
            private int _rowCount;
            private int _layerCount;

            float[] _position;

            //Stack Genetic Data
            private int[] _dnaGenes;
            private float _fitness;

            //Stack Data
            private string _name;
            private float _meanStackDensity;
            private float _maxLayerDensity;
            private float _minLayerDensity;
            private float _maxAge;
            private float _avgAge;

            //Layer Data
            private float[] _layerDensities;
            private float[] _layerAvgAges;
            private float[] _layerMaxAges;


            //Cell Data
            private int[,,] _cellStates;
            private int[,,] _cellAges;

            /// <summary>
            /// 
            /// </summary>


            public float[] Position
            {
                get { return _position; }
                set { _position = value; }
            }

            public string Name
            {
                get { return _name; }
                set { _name = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public float MeanStackDensity
            {
                get { return _meanStackDensity; }
                set { _meanStackDensity = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            /// <returns></returns>
            public float MaxLayerDensity
            {
                get { return _maxLayerDensity; }
                set { _maxLayerDensity = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public float MinLayerDensity
            {
                get { return _minLayerDensity; }
                set { _minLayerDensity = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public float MaxAge
            {
                get { return _maxAge; }
                set { _maxAge = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public float AvgAge
            {
                get { return _avgAge; }
                set { _avgAge = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public int[] DNAGENES
            {
                get { return _dnaGenes; }
                set { _dnaGenes = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public float Fitness
            {
                get { return _fitness; }
                set { _fitness = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public int RowCount
            {
                get { return _rowCount; }
                set { _rowCount = value; }

            }


            /// <summary>
            /// 
            /// </summary>
            public int ColumnCount
            {
                get { return _columnCount; }
                set { _columnCount = value; }

            }


            /// <summary>
            /// 
            /// </summary>
            public int LayerCount
            {
                get { return _layerCount; }
                set { _layerCount = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public float[] LayerAvgAges
            {
                get { return _layerAvgAges; }
                set { _layerAvgAges = value; }

            }

            /// <summary>
            /// 
            /// </summary>
            public float[] LayerDensities
            {
                get { return _layerDensities; }
                set { _layerDensities = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public float[] LayerMaxAges
            {
                get { return _layerMaxAges; }
                set { _layerMaxAges = value; }
            }


            /// <summary>
            /// 
            /// </summary>
            public int[,,] CellStates
            {
                get { return _cellStates; }
                set { _cellStates = value; }
            }

            /// <summary>
            /// 
            /// </summary>
            public int[,,] CellAges
            {
                get { return _cellAges; }
                set { _cellAges = value; }
            }
        }


        /// <summary>
        /// Static methods for importing from and exporting to external formats.
        /// </summary>
        public static class Interop
        {
            /// <summary>
            /// Binary serialization
            /// </summary>
            /// <typeparam name="T"></typeparam>
            /// <param name="item"></param>
            /// <param name="path"></param>
            public static void SerializeBinary<T>(T item, string path)
            {
                using (Stream stream = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    var formatter = new BinaryFormatter();
                    formatter.Serialize(stream, item);
                }
            }


            /// <summary>
            /// Binary deserialization
            /// </summary>
            /// <param name="path"></param>
            /// <returns></returns>
            public static object DeserializeBinary(string path)
            {
                using (Stream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    var formatter = new BinaryFormatter();
                    return formatter.Deserialize(stream);
                }
            }


            /// <summary>
            /// Binary deserialization
            /// </summary>
            /// <param name="path"></param>
            /// <returns></returns>
            public static T DeserializeBinary<T>(string path)
            {
                return (T)DeserializeBinary(path);
            }



        }
    }
}
